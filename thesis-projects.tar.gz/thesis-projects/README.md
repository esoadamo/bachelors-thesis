# Archive structure

This archive contains all projects created as part of this thesis, each in a single sub-directory of this archive:

- `web-frontend-angular` - the main goal of this thesis, contains source the new KSI web application
- `web-backend-swagger` - the OpenAPI proxy defining the endpoint structure for the backend, referenced in subsection 4.2.2.
- `seminar-till-2014-converter` - a project for converting historic TeX tasks into an SQL statement that can be inserted into the database

The `web-frontend-angular` project contains a `.git` sub-directory to demonstrate automatic changelog generation, as referenced in subsection `5.1.5`.

Each projects' sub-directory contains a `README.md` file with relevant information for the project.


