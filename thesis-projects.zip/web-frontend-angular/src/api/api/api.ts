export * from './default.service';
import { DefaultService } from './default.service';
export const APIS = [DefaultService];
