// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface EmptyDict {}
export interface PossibleErrorDict extends EmptyDict {
    error?: string;
}
