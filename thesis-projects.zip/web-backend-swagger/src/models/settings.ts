export interface ChangePasswordRequest {
    old_password: string;
    new_password: string;
    new_password2: string;
}

export interface ChangePasswordResult {
    result: 'ok';
}
