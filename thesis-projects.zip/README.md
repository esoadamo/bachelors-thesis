# Archive structure

This archive contains all three projects created as part of this thesis, each in a single sub-directory of this archive:

- `web-frontend-angular` - the main goal of this thesis, contains source the new KSI web application
- `web-backend-swagger` - the OpenAPI proxy defining the endpoint structure for the backend, referenced in subsection 4.2.2.
- `seminar-till-2014-converter` - a project for converting historic TeX tasks into an SQL statement that can be inserted into the database

The `web-frontend-angular` project contains a `.git` sub-directory to demonstrate automatic changelog generation, as referenced in subsection `5.1.5`.

A fourth project included in this archive, `web-backend`, was only partially modified as part of this thesis. In relation to section `4.3`, the most relevant part of this project is its `.docker` sub-directory. 

Each project's sub-directory contains a `README.md` file with relevant information for the project.
