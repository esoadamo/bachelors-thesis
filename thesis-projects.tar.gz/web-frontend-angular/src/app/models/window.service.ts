export interface WindowSize {
  height: number;
  width: number;
}

export interface PageScroll {
  depth: number;
  change: number;
}
