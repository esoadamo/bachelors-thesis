export type WaveView = 'linear' | 'wave-graph' | 'graph';
