import { Year } from "../../api";

export type YearSelect = Pick<Year, 'year' | 'id'>;
