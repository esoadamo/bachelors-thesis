export interface ForgottenPasswordRequest {
    email: string;
}

export interface ForgottenPasswordResult {
    result: 'ok';
}
