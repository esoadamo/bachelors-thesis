LOCKFILE = '/var/lock/ksi-task-merge'
