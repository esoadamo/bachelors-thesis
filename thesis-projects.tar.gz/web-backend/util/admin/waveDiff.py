LOCKFILE = '/var/lock/ksi-wave-diff'
