GIT_SEMINAR_PATH = 'data/seminar/'
TASK_MOOSTER_PATH = 'task-plain/'
